package dao.utility;

//public class GetCustomerDetails {
//    private GetCustomerDetails() {
//    } // private constructor
//
//    public static Customer getCustomerDetails() {
//        try{
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        return null;
//    }
//}
